import React, { useEffect } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./Select";
import { Slider } from "./Slider";
import { PatternConfig } from "../helpers/patternConfig";
import styles from "./GeneratorControls.module.css";

interface GeneratorControlsPatternProps {
  config: PatternConfig;
  onChange: (key: keyof PatternConfig, value: any) => void;
}

export const GeneratorControlsPattern = ({
  config,
  onChange,
}: GeneratorControlsPatternProps) => {
  // Show branches slider for star-based patterns (zellige, zouaq, fractalRosette, and mandala)
  const showBranchSlider = ["zellige", "zouaq", "fractalRosette", "mandala"].includes(config.type);

  // Set default branch count when switching to star patterns
  useEffect(() => {
    if (["zellige", "zouaq", "fractalRosette", "mandala"].includes(config.type) && !config.branches) {
      // Different default for Mandala? 8 is fine.
      onChange("branches", 8);
    }
  }, [config.type]);

  return (
    <div className={styles.sectionGroup}>
      <div className={styles.section}>
        <label className={styles.label}>Pattern Type</label>
        <Select
          value={config.type}
          onValueChange={(val) => onChange("type", val)}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="zellige">Star</SelectItem>
            <SelectItem value="zouaq">Zouaq (Strapwork)</SelectItem>
            <SelectItem value="rosette">Concentric Rosette</SelectItem>
            <SelectItem value="fractalRosette">Fractal + Rosette</SelectItem>
            <SelectItem value="mandala">Mandala Arabesque</SelectItem>
            <SelectItem value="amazigh">Amazigh (Berber)</SelectItem>
            <SelectItem value="shamsa">Shamsa (Sun)</SelectItem>
            <SelectItem value="tawriq">Tawriq (Floral)</SelectItem>
                        <SelectItem value="tastir">Tastir (Zellige)</SelectItem>
            <SelectItem value="cachemire">Cachemire (Paisley)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {showBranchSlider && (
        <div className={styles.section}>
          <label className={styles.label}>
            Number of Branches ({config.branches || 8})
          </label>
          <Slider
            value={[config.branches || 8]}
            min={config.type === "mandala" ? 6 : 3}
            max={config.type === "mandala" ? 12 : 100}
            step={config.type === "mandala" ? 2 : 1}
            onValueChange={(vals) => onChange("branches", vals[0])}
          />
        </div>
      )}
    </div>
  );
};