import React from "react";
import {
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "./Accordion";
import styles from "./GeneratorControls.module.css";

interface GeneratorControlsSectionProps {
  value: string;
  title: string;
  children: React.ReactNode;
}

export const GeneratorControlsSection = ({
  value,
  title,
  children,
}: GeneratorControlsSectionProps) => {
  return (
    <AccordionItem value={value} className={styles.accordionItem}>
      <AccordionTrigger className={styles.accordionTrigger}>
        {title}
      </AccordionTrigger>
      <AccordionContent className={styles.accordionContent}>
        <div className={styles.accordionContentInner}>{children}</div>
      </AccordionContent>
    </AccordionItem>
  );
};