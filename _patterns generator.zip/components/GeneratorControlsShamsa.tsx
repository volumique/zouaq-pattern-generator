import React from "react";
import { Slider } from "./Slider";
import { Switch } from "./Switch";
import { PatternConfig } from "../helpers/patternGenerator";
import styles from "./GeneratorControlsShamsa.module.css";

interface GeneratorControlsShamsaProps {
  config: PatternConfig;
  onChange: (key: keyof PatternConfig, value: any) => void;
}

export const GeneratorControlsShamsa = ({
  config,
  onChange,
}: GeneratorControlsShamsaProps) => {
  return (
    <div className={styles.sectionGroup}>
      <div className={styles.section}>
        <label className={styles.label}>
          Central Petals ({config.shamsaCentralPetals ?? 12})
        </label>
        <Slider
          value={[config.shamsaCentralPetals ?? 12]}
          min={8}
          max={24}
          step={2}
          onValueChange={(vals) => onChange("shamsaCentralPetals", vals[0])}
        />
      </div>

      <div className={styles.section}>
        <label className={styles.label}>
          Satellite Count ({config.shamsaSatelliteCount ?? 8})
        </label>
        <Slider
          value={[config.shamsaSatelliteCount ?? 8]}
          min={4}
          max={12}
          step={2}
          onValueChange={(vals) => onChange("shamsaSatelliteCount", vals[0])}
        />
      </div>

      <div className={styles.section}>
        <label className={styles.label}>
          Satellite Petals ({config.shamsaSatellitePetals ?? 12})
        </label>
        <Slider
          value={[config.shamsaSatellitePetals ?? 12]}
          min={6}
          max={16}
          step={2}
          onValueChange={(vals) => onChange("shamsaSatellitePetals", vals[0])}
        />
      </div>

      <div className={styles.section}>
        <label className={styles.label}>
          Satellite Size ({(config.shamsaSatelliteScale ?? 0.35).toFixed(2)})
        </label>
        <Slider
          value={[config.shamsaSatelliteScale ?? 0.35]}
          min={0.2}
          max={0.5}
          step={0.05}
          onValueChange={(vals) => onChange("shamsaSatelliteScale", vals[0])}
        />
      </div>

      <div className={styles.section}>
        <div className={styles.row}>
          <label className={styles.label} htmlFor="shamsa-pentagons">
            Pentagon Rings
          </label>
          <Switch
            id="shamsa-pentagons"
            checked={config.shamsaShowPentagons ?? true}
            onCheckedChange={(val) => onChange("shamsaShowPentagons", val)}
          />
        </div>
      </div>

      <div className={styles.section}>
        <div className={styles.row}>
          <label className={styles.label} htmlFor="shamsa-connectors">
            Square Connectors
          </label>
          <Switch
            id="shamsa-connectors"
            checked={config.shamsaShowSquareConnectors ?? true}
            onCheckedChange={(val) => onChange("shamsaShowSquareConnectors", val)}
          />
        </div>
      </div>
    </div>
  );
};