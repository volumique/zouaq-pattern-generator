/**
 * @file LandingHeroPattern.tsx
 * @description A visual component specifically crafted for the landing page hero background.
 */

import React, { useMemo } from "react";
import { generatePattern, PatternConfig } from "../helpers/patternGenerator";
import styles from "./LandingHeroPattern.module.css";

// Static config for the background moved outside to avoid re-creation
const LANDING_CONFIG: PatternConfig = {
  type: "zellige",
  branches: 12,
  lineWidth: 1,
  tiling: 6, // Large grid to cover screen
  colors: {
    primary: "#1E4D8C", // Fes Blue
    secondary: "#046307", // Emerald Green
    accent: "#C35831", // Terracotta
    background: "transparent",
    line: "rgba(255,255,255,0.1)",
  },
};

/**
 * Renders a large, slowly rotating geometric pattern using the core generator logic,
 * but customized with fixed, subtle styling and a glowing SVG filter for visual flair.
 */
export const LandingHeroPattern = () => {
  // Memoize pattern generation so it only runs once and doesn't hinder page load rendering.
  const pattern = useMemo(() => generatePattern(LANDING_CONFIG), []);

  return (
    <div className={styles.container}>
      <svg
        className={styles.rotatingPattern}
        width="150%"
        height="150%"
        viewBox={pattern.viewBox}
      >
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2.5" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        {pattern.shapes.map((shape, index) => (
          <polygon
            key={index}
            points={shape.points.map((p) => `${p.x},${p.y}`).join(" ")}
            fill={shape.color}
            stroke={shape.stroke}
            strokeWidth={shape.strokeWidth}
            fillOpacity={0.6}
          />
        ))}
      </svg>
    </div>
  );
};