/**
 * @file LandingPageLayout.tsx
 * @description A layout wrapper component dedicated to the informational Landing page.
 */

import { ReactNode } from "react";
import styles from "./LandingPageLayout.module.css";

/**
 * Handles minimum viewport height constraints, sets standard theme typography/background colors,
 * and normalizes the styling. Acts as the root node wrapper structurally placed by React Router layouts.
 * 
 * @param props.children - The marketing page contents.
 */
export function LandingPageLayout({ children }: { children: ReactNode }) {
  return <div className={styles.layout}>{children}</div>;
}